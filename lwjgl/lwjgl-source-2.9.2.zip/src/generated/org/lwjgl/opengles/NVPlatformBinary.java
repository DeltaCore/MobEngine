/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class NVPlatformBinary {

	/**
	 * Accepted by the &lt;binaryformat&gt; parameter of ShaderBinary: 
	 */
	public static final int GL_NVIDIA_PLATFORM_BINARY_NV = 0x890B;

	private NVPlatformBinary() {}
}
