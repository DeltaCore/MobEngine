/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class VIVShaderBinary {

	/**
	 * Accepted by the &lt;binaryformat&gt; parameter of ShaderBinary: 
	 */
	public static final int GL_SHADER_BINARY_VIV = 0x8FC4;

	private VIVShaderBinary() {}
}
