/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class EXTTextureFilterAnisotropic {

	/**
	 *  Accepted by the &lt;pname&gt; parameters of GetTexParameterfv,
	 *  GetTexParameteriv, TexParameterf, TexParameterfv, TexParameteri,
	 *  and TexParameteriv:
	 */
	public static final int GL_TEXTURE_MAX_ANISOTROPY_EXT = 0x84FE;

	/**
	 *  Accepted by the &lt;pname&gt; parameters of GetBooleanv,
	 *  GetFloatv, and GetIntegerv:
	 */
	public static final int GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT = 0x84FF;

	private EXTTextureFilterAnisotropic() {}
}
