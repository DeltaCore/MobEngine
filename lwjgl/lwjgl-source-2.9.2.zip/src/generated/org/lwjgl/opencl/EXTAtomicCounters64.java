/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opencl;

import org.lwjgl.*;
import java.nio.*;

public final class EXTAtomicCounters64 {

	/**
	 * CLDevice query: Max number of atomic counters that can be used by a kernel. 
	 */
	public static final int CL_DEVICE_MAX_ATOMIC_COUNTERS_EXT = 0x4032;

	private EXTAtomicCounters64() {}
}
