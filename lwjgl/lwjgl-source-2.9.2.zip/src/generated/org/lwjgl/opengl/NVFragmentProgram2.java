/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class NVFragmentProgram2 {

	/**
	 *  Accepted by the &lt;pname&gt; parameter of GetProgramivARB:
	 */
	public static final int GL_MAX_PROGRAM_EXEC_INSTRUCTIONS_NV = 0x88F4,
		GL_MAX_PROGRAM_CALL_DEPTH_NV = 0x88F5,
		GL_MAX_PROGRAM_IF_DEPTH_NV = 0x88F6,
		GL_MAX_PROGRAM_LOOP_DEPTH_NV = 0x88F7,
		GL_MAX_PROGRAM_LOOP_COUNT_NV = 0x88F8;

	private NVFragmentProgram2() {}
}
