/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class NVDeepTexture3D {

	/**
	 *  Accepted by the &lt;pname&gt; parameter of GetBooleanv, GetDoublev, GetIntegerv
	 *  and GetFloatv:
	 */
	public static final int GL_MAX_DEEP_3D_TEXTURE_WIDTH_HEIGHT_NV = 0x90D0,
		GL_MAX_DEEP_3D_TEXTURE_DEPTH_NV = 0x90D1;

	private NVDeepTexture3D() {}
}
